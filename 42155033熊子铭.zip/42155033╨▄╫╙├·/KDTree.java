package com.test.myjob;

import java.util.ArrayList;
import java.util.List;

public class KDTree {
    private static class KDTreeNode {
        public int dimension;
        public double[] point;
        public KDTreeNode left;
        public KDTreeNode right;

        public KDTreeNode(int dimension, double[] point) {
            this.dimension = dimension;
            this.point = point;
            this.left = null;
            this.right = null;
        }
    }

    private KDTreeNode root;
    private int k;

    public KDTree(int k) {
        this.root = null;
        this.k = k;
    }

    public void insert(double[] point) {
        root = insert(root, point, 0);
    }

    /**
     The insert() method is used to add a new point to the k-d tree. It takes an array of double values as a parameter, which represents the point to be inserted.
     The method works by starting at the root of the tree and recursively adding the point to the left or right subtree depending on its coordinates in the current split dimension.
     The depth parameter is used to determine which dimension to use for splitting at each level of the tree.
     */
    private KDTreeNode insert(KDTreeNode node, double[] point, int depth) {
        if (node == null) {
            return new KDTreeNode(depth % k, point);
        }

        if (point[node.dimension] < node.point[node.dimension]) {
            node.left = insert(node.left, point, depth + 1);
        } else {
            node.right = insert(node.right, point, depth + 1);
        }

        return node;
    }

    /**
     The range() method is used to search for points in a specified range of coordinates.
     It takes two arrays of double values as parameters, which represent the lower and upper bounds of the range, respectively.
     The method works by starting at the root of the tree and recursively searching the left and right subtrees if the query range could possibly intersect them.
     It returns a List of points that fall within the specified range. The isInRange() method is used to check whether a point falls within the specified range.
     */
    public List<double[]> range(double[] lower, double[] upper) {
        List<double[]> result = new ArrayList<>();
        range(root, lower, upper, result);
        return result;
    }

    private void range(KDTreeNode node, double[] lower, double[] upper, List<double[]> result) {
        if (node == null) {
            return;
        }

        if (isInRange(node.point, lower, upper)) {
            result.add(node.point);
        }

        if (lower[node.dimension] <= node.point[node.dimension]) {
            range(node.left, lower, upper, result);
        }

        if (upper[node.dimension] >= node.point[node.dimension]) {
            range(node.right, lower, upper, result);
        }
    }


    private boolean isInRange(double[] point, double[] lower, double[] upper) {
        for (int i = 0; i < k; i++) {
            if (point[i] < lower[i] || point[i] > upper[i]) {
                return false;
            }
        }
        return true;
    }
}
