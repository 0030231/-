import com.test.myjob.KDTree;

import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        KDTree tree = new KDTree(2);

// insert some points into the tree
        double[] p1 = new double[] {3, 4};
        double[] p2 = new double[] {1, 2};
        double[] p3 = new double[] {5, 6};
        double[] p4 = new double[] {7, 8};
        double[] p5 = new double[] {9, 10};

        tree.insert(p1);
        tree.insert(p2);
        tree.insert(p3);
        tree.insert(p4);
        tree.insert(p5);

// search for points in the range [2, 5] x [3, 7]
        double[] lower = new double[] {2, 3};
        double[] upper = new double[] {5, 7};

        List<double[]> result = tree.range(lower, upper);

        for (double[] point : result) {
            System.out.println(Arrays.toString(point));
        }

    }
}